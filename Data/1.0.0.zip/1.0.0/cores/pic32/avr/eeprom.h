#ifndef __EEPROM_H_
#define __EEPROM_H_ 1

/* For AVR */
#if defined(__AVR__)
    #include <avr/io.h>
#endif

#endif /* __EEPROME_H_ */
