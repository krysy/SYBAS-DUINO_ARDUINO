/*
Sybas Duino E13 pin defines
*/

#define DIO0  1
#define DIO1  2
#define DIO2  3
#define DIO3  4
#define DIO4  13
#define DIO5  12
#define DIO6  11
#define DIO7  7
#define DIO8  5
#define DIO9  8
#define DIO10 14
#define DIO11 9
#define DIO12 6
#define DIO13 10